package com.example.recipeorganizer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

        var recipeName = mutableListOf<Any>()
        var recipeTag = mutableListOf<Any>()
        var recipeBody = mutableListOf<Any>()

        fun enter(view: View) {

            recipeName.add(enterName.text.toString())
            recipeTag.add(enterTag.text.toString())
            recipeBody.add(enterRecipe.text.toString())

//            var recipeName = enterName.text.toString()
//            var tagOfRecipe = enterTag.text
//            var tagOfRecipeList = tagOfRecipe.split(",").map { it.trim() }
//            var bodyOfRecipe = enterRecipe.text.toString()

//            var recipe = listOf(recipeName, tagOfRecipeList, bodyOfRecipe)
//            listOfRecipes.add(recipe)

            println(recipeName)
            println(recipeTag)
            println(recipeBody)

            enterName.text.clear()
            enterTag.text.clear()
            enterRecipe.text.clear()

        }

        fun toRecipeActivity(view: View) {
            var recipeNameArray = recipeName.toTypedArray()
            var recipeTagArray = recipeTag.toTypedArray()
            var recipeBodyArray = recipeBody.toTypedArray()

            val intent = Intent(this, SecondaryActivity::class.java)
            intent.putExtra("name", recipeNameArray)
            intent.putExtra("tag", recipeTagArray)
            intent.putExtra("body", recipeBodyArray)
            startActivity(intent)
        }

        fun toHelp(view: View) {
            val intent = Intent(this, HelpActivity::class.java)
            startActivity(intent)
        }



}




