package com.example.recipeorganizer.model

class Place {
    var CountryName: String?=null
    var CityName: String?=null
}