package com.example.recipeorganizer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recipeorganizer.data.PlaceListAdapter
import com.example.recipeorganizer.model.Place
import kotlinx.android.synthetic.main.activity_secondary.*

class SecondaryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)

        var SrecipeName = intent.getStringArrayExtra("name")
        var SrecipeTag = intent.getStringArrayExtra("tag")
        var SrecipeBody = intent.getStringArrayExtra("body")

        var adapter:PlaceListAdapter?=null
        var countryList:ArrayList<Place>?=null
        var layoutManager:RecyclerView.LayoutManager?=null

        countryList = ArrayList<Place>()
        layoutManager = LinearLayoutManager(this)
        adapter = PlaceListAdapter(countryList, this)

        myRecyclerView.layoutManager = layoutManager
        myRecyclerView.adapter = adapter

        val countryNameList:Array<String> = arrayOf("Chicken Dinner", "Spaghetti", "Porkchops")
        val cityNameList:Array<String> = arrayOf("Grill on direct heat until internal temperature is 165.", "Boil noodles. Throw them against the wall and if they stick, they're done", "Grill on direct heat for 12 minutes, flipping once.")

        for (i in countryNameList.indices) {
            val place = Place()
            place.CountryName = countryNameList[i]
            place.CityName = cityNameList[i]
            countryList.add(place)
        }

        adapter.notifyDataSetChanged()

        val actionBar = supportActionBar
        actionBar!!.title = "Recipe List"
        actionBar.setDisplayHomeAsUpEnabled(true)
    }

    fun toHelp(view: View) {
        val intent = Intent(this, HelpActivity::class.java)
        startActivity(intent)
    }

}