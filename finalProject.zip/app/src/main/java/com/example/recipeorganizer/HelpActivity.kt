package com.example.recipeorganizer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceActivity
import android.view.View

class HelpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        val actionBar = supportActionBar
        actionBar!!.title = "Recipe List"
        actionBar.setDisplayHomeAsUpEnabled(true)
    }

    fun toPreferences (view: View) {
        val intent = Intent(this, PreferencesActivity::class.java)
        startActivity(intent)
    }
}